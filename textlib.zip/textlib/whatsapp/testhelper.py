import re
import pandas   as pd
import numpy    as np
import emoji

from collections     import Counter

def import_data(file, path = ''):
  
   
    with open(path + file, encoding = 'utf-8') as outfile:
        raw_text = outfile.readlines()
    dic={'Message_Clean':raw_text[0]}
    dic['Message_Only_Text']=re.sub(r'[^a-zA-Z ]+', '', raw_text[0].lower())
    l=''
    for c in raw_text[0]:
        if c in emoji.UNICODE_EMOJI:
            l=l+c
    dic['emojis']=l
    # Convert dictionary to dataframe
    #df = pd.DataFrame(dic)
   
    return dic
    

    


    